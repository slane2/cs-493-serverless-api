const serverless = require('serverless-http');
const bodyParser = require('body-parser');
const AWS = require('aws-sdk');
const express = require('express'),
    app = express();

// from tutorial at https://www.serverless.com/blog/serverless-express-rest-api
const MUSIC_TABLE = process.env.MUSIC_TABLE;
const dynamoDb = new AWS.DynamoDB.DocumentClient();

app.use(bodyParser.json({ strict: false }));

app.get('/', function (req, res) {
    res.send('Please don\'t stop the music')
})

// Get Genre endpoint
app.get('/genres/', function (req, res) {
    const params = {
        TableName: 'music',
        KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
        ExpressionAttributeValues: {
            ':pk': 'genre',
            ':sk': 'genre'
        },
    }

    dynamoDb.query(params, function(err, data) {
    if (err) console.log(err);
    else {
        console.log(data);
        genres = [];
        data.Items.forEach(function(item) {
        genres.push(item.info.genre);
        });
        res.send({
        "Genres": genres
        });
    }
    });
    })

// Get Artist for Genre endpoint
app.get('/artists/for/:genre', function (req, res) {
    const genre = req.params.genre;
    const params = {
        TableName: 'music',
        KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
        ExpressionAttributeValues: {
            ':pk': 'genre#' + genre,
            ':sk': 'artist'
        },
    }

    dynamoDb.query(params, function(err, data) {
        if (err) console.log(err);
        else {
            console.log(data);
            artists = [];
            data.Items.forEach(function(item) {
                artists.push(item.info.artist);
            });
            res.send({
                "Artists": artists
            });
        }
    });
})

// Get Albums for Artist endpoint
app.get('/albums/for/:artist', function (req, res) {
    const artist = req.params.artist;
    const params = {
        TableName: 'music',
        KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
        ExpressionAttributeValues: {
        ':pk': 'artist#' + artist,
        ':sk': 'album'
        },
    }

    dynamoDb.query(params, function(err, data) {
        if (err) console.log(err);
        else {
            console.log(data);
            albums = [];
            data.Items.forEach(function(item) {
            albums.push(item.info.album);
            });
            res.send({
                "Albums": albums
            });
        }
    });
})

// Get Songs for Album endpoint
app.get('/songs/for/:album', function (req, res) {
    const album = req.params.album;
    const params = {
        TableName: 'music',
        KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
        ExpressionAttributeValues: {
            ':pk': 'album#' + album,
            ':sk': 'song'
        },
    }

    dynamoDb.query(params, function(err, data) {
        if (err) console.log(err);
        else {
            console.log(data);
            songs = [];
            data.Items.forEach(function(item) {
            songs.push(item.info.song);
            });
            res.send({
                "Songs": songs
            });
        }
    });
})

// Get Song endpoint
app.get('/song/:song', function (req, res) {
    const song = req.params.song;
    const params = {
        TableName: 'music',
        KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
        ExpressionAttributeValues: {
        ':pk': 'song',
        ':sk': 'song#' + song
        },
    }

    dynamoDb.query(params, function(err, data) {
        if (err) console.log(err);
        else {
            console.log(data);
            song_key = data.Items[0].info.key;
            var s3 = new AWS.S3();
            let url = s3.getSignedUrl('getObject', {
                Bucket: 'shaylalalala522',
                Key: song_key, 
            });
            res.send({
                "URL": url
            });
        }
    });
})

module.exports.handler = serverless(app);